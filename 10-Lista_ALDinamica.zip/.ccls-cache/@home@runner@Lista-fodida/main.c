#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}

//Em resumo, a principal diferença entre essas duas bibliotecas está na forma como as operações de inserção são realizadas e como a memória é alocada para os novos nodos. A primeira biblioteca insere elementos diretamente na lista e fornece uma função para retirar elementos. A segunda biblioteca insere elementos modificando o nodo pred e não fornece uma função para retirar elementos.

